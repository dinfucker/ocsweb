<?php
echo "<script>location.replace('/install')</script>";
?>