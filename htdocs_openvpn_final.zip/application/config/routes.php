<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$route['default_controller'] = 'seller/seller';
$route['join'] = 'seller/seller';
$route['android'] = 'seller/android';
$route['download'] = 'seller/config';
$route['servers'] = 'seller/seller/$1';
$route['index'] = 'seller/main';

$route['sign-in'] = 'login/login';
$route['login'] = 'login/login';
$route['sign-out'] = 'login/logout';
$route['sign-up'] = 'login/register';
$route['you_a_hacker_?'] = 'seller/error';
$route['error'] = 'seller/error';
$route['_topup/truemoney'] = 'seller/topup';
$route['_topup/truewallet'] = 'seller/topups';

$route['verified_email/(:any)/(:any)'] = 'seller/verified_email/$1/$2';
$route['verified_mail'] = 'seller/verified_mail';
$route['index/(:any)/setting'] = 'login/setting';
$route['_client/account/(:any)'] = 'seller/cek_account/$1';
$route['_client/account/reset/(:any)/(:any)'] = 'seller/reset_sshpass/$1/$2';
$route['_client/account/expup/(:any)/(:any)'] = 'seller/update_sshuser/$1/$2';

$route['checkuot/month/(:any)/(:any)/(:any)/(:any)'] = 'seller/buy/$4';
$route['checkuot/day/(:any)/(:any)/(:any)/(:any)'] = 'seller/buyday/$4';

$route['autowallet/(:any)'] = 'autowallet/index/$1';
$route['panel/reseller/(:any)/addsaldo-via-hp'] = 'seller/addsaldo_hp';
$route['panel/reseller/(:any)/addsaldo-via-req'] = 'seller/addsaldo_req';
$route['admins/index'] = 'admin/admin/$1';
$route['_admin/checkmember'] = 'admin/userListing';
$route['index/administrator/edit/(:any)/(:any)/(:any)'] = 'admin/lock/$2/$3';
$route['index/administrator/edit/(:any)/(:any)'] = 'admin/edit/$2';
$route['index/administrator/(:any)/(:any)'] = 'admin/server/$2';
$route['_admin/howtotopup'] = 'admin/howtotopup';
$route['_client/luckynumber'] = 'seller/luckynumber';
$route['_client/editemail'] = 'seller/edit_email';
$route['_client/gencode'] = 'ref/gencode';

$route['index/administrator/topuser/(:any)/(:any)'] = 'admin/topup_user/$2';
$route['index/administrator/edituser/(:any)/(:any)'] = 'admin/edit_user/$2';
$route['index/admin/register/(:any)'] = 'admin/register/$1';