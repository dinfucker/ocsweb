<?php defined('BASEPATH') OR exit('No direct script access allowed'); 
require APPPATH . '/libraries/BaseController.php';///////////////////
class Delete extends BaseController{///////////////////////////////// 
public function __construct(){///////////////////////////////////////
parent::__construct();/////////////////////////////////////////////// 
$this->load->model('user_model');////////////////////////////////////
$this->load->helper('url_helper');///////////////////////////////////
$this->load->library(array('session'));//////////////////////////////
$this->load->model('dashboard_model');///////////////////////////////
}////////////////////////////////////////////////////////////////////
private function _set_view($file, $init){////////////////////////////
$data = new stdClass();//////////////////////////////////////////////
$data -> msg = $this->user_model->seller_notify();///////////////////
$data->user = $this->user_model->get_user($_SESSION['user_id']);/////
$this->load->view('panel/base/page_header', $data);//////////////////
$this->load->view($file, $init);/////////////////////////////////////
$this->load->view('panel/base/footer');//////////////////////////////
}

function pro_true($id)  {
						if ( isset($_SESSION['username']) && $_SESSION['is_admin'] === true ) 
						{	
						if ($this->user_model->del_pro_true($id))
						{
						redirect(base_url('admin/pro_true'));
						}
						} else 
						{ 
						redirect(base_url('sign-in')); 
						}
						
}
function pro_dtac($id)  {
						if ( isset($_SESSION['username']) && $_SESSION['is_admin'] === true ) 
						{	
						if ($this->user_model->del_pro_dtac($id))
						{
						redirect(base_url('admin/pro_true'));
						}
						} else 
						{ 
						redirect(base_url('sign-in')); 
						}
						
}
function pro_ais($id)   {
						if ( isset($_SESSION['username']) && $_SESSION['is_admin'] === true ) 
						{	
						if ($this->user_model->del_pro_ais($id))
						{
						redirect(base_url('admin/pro_true'));
						}
						} else 
						{ 
						redirect(base_url('sign-in')); 
						}
						  
}
function terms_use($id)   {
						if ( isset($_SESSION['username']) && $_SESSION['is_admin'] === true ) 
						{	
						if ($this->user_model->del_terms_use($id))
						{
						redirect(base_url('admin/terms_use'));
						}
						} else 
						{ 
						redirect(base_url('sign-in')); 
						}
						  
}
function new_news($id)   {
						if ( isset($_SESSION['username']) && $_SESSION['is_admin'] === true ) 
						{	
						if ($this->user_model->del_new_news($id))
						{
						redirect(base_url('admin/new_news'));
						}
						} else 
						{ 
						redirect(base_url('sign-in')); 
						}
						  
}
}