<?php defined('BASEPATH') OR exit('No direct script access allowed');
/*
* Copyright (c) 2008-2019 KU-LNW-POR <Kulnwpor@gmail.com>,
* Truewallet id : 097-026-7262
* 2008-2019 http://www.Ocspanel.info
*/
class Seller extends CI_Controller {//////////////////////////////////////////
public function __construct() {///////////////////////////////////////////////
parent::__construct();////////////////////////////////////////////////////////
$this->load->model('user_model');/////////////////////////////////////////////
$this->load->helper('url_helper');////////////////////////////////////////////
$this->load->library('Truepay');//////////////////////////////////////////////
$this->load->library('sshcepat');/////////////////////////////////////////////
$this->load->library(array('session'));///////////////////////////////////////
}/////////////////////////////////////////////////////////////////////////////
private function _set_view($file, $init) {////////////////////////////////////
$data = new stdClass();///////////////////////////////////////////////////////
$data->user = $this->user_model->get_user($_SESSION['user_id']);//////////////
$this->user_model->get_user($_SESSION['user_id']);////////////////////////////
$this->load->view('panel/base/page_header', $data);///////////////////////////
$this->load->view($file, $init);//////////////////////////////////////////////
$this->load->view('panel/base/footer');///////////////////////////////////////
} ////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////
//**************************************************************************//		
public function addsaldo_hp() {
/*------------------------------------------------------------------------------*/		
$this->load->helper('form');
$this->load->library('form_validation');
if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true) {
$this->form_validation->set_rules('sender', 'Pengirim', 'trim|required|min_length[4]');
$this->form_validation->set_rules('hp', 'No Telp', 'trim|required|min_length[4]');
$user = $this->user_model->get_user($_SESSION['user_id']);
if ($this->form_validation->run() === false) {
$data = new stdClass();
$data->user = $this->user_model->get_user($_SESSION['user_id']);
$this->_set_view('panel/seller/addsaldo_hp', $data);
} else {
$mkios = $this->input->post('mkios');
$sender = $this->input->post('sender');
$hp = $this->input->post('hp');
$jumlah= $this->input->post('jumlah');
if (empty($mkios)) {
$pesan = $user->username. ' ได้ส่งหมายเลขบัตร : ' .$sender. ' ไปยังเบอร์ : '. $hp .' ราคาบัตร : '. $jumlah;
} else {
$pesan = $user->username. ' Meminta saldo via mkios Dengan no seri ' .$mkios. ' dikirim ke nomor '.$hp.' sebesar : '. $jumlah;
}
$userid=$_SESSION['user_id'];
if ($this->user_model->deposit($userid, $pesan, $jumlah)) {
$data = new stdClass();
$data -> message = 'ขอขอบคุณที่ซื้อ ssh บนเซิร์ฟเวอร์ของเรา โปรดรอสักครู่เมื่อยอดเงินของคุณเพิ่มขึ้นโดยอัตโนมัติการยืนยันนี้ใช้เวลาไม่เกิน 1x24 ชั่วโมง.';
$data->user = $this->user_model->get_user($_SESSION['user_id']);
$this->_set_view('panel/seller/addsaldo_hp', $data);
} else {
echo "database error";
}
}
} else {
redirect(base_url('sign-in'));
}
}
public function addsaldo_req() {	
$this->load->helper('form');
$this->load->library('form_validation');
if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true) {
$this->form_validation->set_rules('sender', 'Rekening', 'trim|required|min_length[4]');
$this->form_validation->set_rules('username', 'username', 'trim|required|min_length[4]');
$this->form_validation->set_rules('rekening', 'tujuan', 'trim|required|min_length[4]');
$user = $this->user_model->get_user($_SESSION['user_id']);
if ($this->form_validation->run() === false) {
$data = new stdClass();
$data->user = $this->user_model->get_user($_SESSION['user_id']);
$this->_set_view('panel/seller/addsaldo_req', $data);
} else {
$sender = $this->input->post('sender');
$username = $this->input->post('username');
$rekening= $this->input->post('rekening');
$jumlah= $this->input->post('jumlah');
$userid=$_SESSION['user_id'];
$pesan = $user->username. ' Meminta saldo sebesar '. $jumlah. ' via reqkening '. $sender. ' Dengan atas nama '.$username.' ke no req '. $rekening;
if ($this->user_model->deposit($userid, $pesan, $jumlah)) { 
$data = new stdClass();
$data -> message = 'Terimakasih telah membeli ssh di server kami . silkan tunggu beberapa saat saldo anda akan bertambah otomatis, konfirmasi ini membutuhkan waktu paling lama 1x24 jam.';
$data->user = $this->user_model->get_user($_SESSION['user_id']);
$this->_set_view('panel/seller/addsaldo_req', $data); 
} else {
echo "database error";
}
}
} else {
redirect(base_url('sign-in'));
}
}	
/////////////////////////////////////////////////////////////////////////////////////////////
//////////////// SERVER VIEW ALL
//////////////// ดูเซิร์ฟเวอร์ทั้งหมด
/////////////////////////////////////////////////////////////////////////////////////////////
public function seller($user=FALSE) {
if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true) {
$user_id='1';
$user = $this->user_model->get_theme_servers($user_id); 
$a='1';
$b='2';

		$data = new stdClass();
		$data->user = $this->user_model->get_user($_SESSION['user_id']);
		$data->server=$this->user_model->get_hostname();


 if($user->theme_servers == $a)
        {
			$this->_set_view('panel/seller/servers_v1', $data);
        }
  else if ($user->theme_servers == $b)
        {
		   $this->_set_view('panel/seller/servers_v2', $data);
        }
   else
        {
           $this->_set_view('panel/seller/servers_v3', $data); 
		   //redirect(base_url('sign-in'));
        }
		}
	else {redirect(base_url('sign-in'));}
}
									
public function day31($user=FALSE)  {
										if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true) {
				
										$data = new stdClass();
										$data->user = $this->user_model->get_user($_SESSION['user_id']);
										$data->server=$this->user_model->get_hostname31();
										$this->_set_view('panel/seller/pay/31days', $data);
									}
										else {redirect(base_url('sign-in'));}
									}
public function day15($user=FALSE)  {
										if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true) {
				
										$data = new stdClass();
										$data->user = $this->user_model->get_user($_SESSION['user_id']);
										$data->server=$this->user_model->get_hostname15();
										$this->_set_view('panel/seller/pay/15days', $data);
									}
										else {redirect(base_url('sign-in'));}
									}
public function day7($user=FALSE)   {
										if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true) {
				
										$data = new stdClass();
										$data->user = $this->user_model->get_user($_SESSION['user_id']);
										$data->server=$this->user_model->get_hostname7();
										$this->_set_view('panel/seller/pay/7days', $data);
									}
										else {redirect(base_url('sign-in'));}
									}
public function day1($user=FALSE)   {
										if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true) {
				
										$data = new stdClass();
										$data->user = $this->user_model->get_user($_SESSION['user_id']);
										$data->server=$this->user_model->get_hostname1();
										$this->_set_view('panel/seller/pay/1days', $data);
									}
										else {redirect(base_url('sign-in'));}
									}	
public function day0($user=FALSE)   {
										if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true) {
				
										$data = new stdClass();
										$data->user = $this->user_model->get_user($_SESSION['user_id']);
										$data->server=$this->user_model->get_hostname0();
										$this->_set_view('panel/seller/pay/0days', $data);
									}
										else {redirect(base_url('sign-in'));}
									}
	
/////////////////////////////////////////////////////////////////////////////////////////////
//////////////// BUY SERVER A::
//////////////// เช่าเซิร์ฟเวอร์ทั้งหมด
/////////////////////////////////////////////////////////////////////////////////////////////
//**************************************************************************//
//--------------------------------------------------------------------------//
///////////////////////////////////////////////////////////////////////////////
///////////////////// BUY VPN SSH
///////////////////////////////////////////////////////////////////////////////
//--------------------------------------------------------------------------//
//**************************************************************************//
public function buyday($id=FALSE) {
$this->load->helper('form');
$this->load->library('form_validation');
	
if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true) {
	if ($this->user_model->get_hostname($id)->Status) {
		$bux=$this->user_model->get_hostname($id)->Price;
		$lop=$this->user_model->get_hostname($id)->Expired;
		$buy_total = $bux / $lop ;
		
		if ($this->user_model->get_user($_SESSION['user_id'])->saldo < $buy_total) {
		/***************************************************/
		$data = new stdClass();
		$data->message='<div class="alert alert-danger">Topup | ยอดเงินของคุณไม่เพียงพอ</div>';
		$data->user = $this->user_model->get_user($_SESSION['user_id']);
		$data->server=$this->user_model->get_hostname(); 
		/***************************************************/
		$user_id='1';
		$user = $this->user_model->get_theme_servers($user_id); 
		$a='1';
		$b='2';
		/***************************************************/
		/////////////////////////////////////////////////////
		if($user->theme_servers == $a)
        {
			$this->_set_view('panel/seller/servers_v1', $data);
        }
		else if ($user->theme_servers == $b)
        {
		   $this->_set_view('panel/seller/servers_v2', $data);
        }
   		else
        {
           $this->_set_view('panel/seller/servers_v3', $data); 
		   //redirect(base_url('sign-in'));
        }
		/////////////////////////////////////////////////////
} else { ////////////////////////////////////////////////////
		$this->form_validation->set_rules('username', 'Username ห้ามเว้นว่าง', 'trim|required|alpha_numeric|min_length[5]|is_unique[sshuser.username]', array('is_unique' => 'ชื่อบัญชีนี้มีอยู่แล้ว กรุณาใช้ชื่อบัญชีอื่น.')); 
		$this->form_validation->set_rules('password', 'Password ห้ามเว้นว่าง', 'trim|required|min_length[5]');
		/***************************************************/
		if ($this->form_validation->run() === false) {
		$data = new StdClass();
		$data->user = $this->user_model->get_user($_SESSION['user_id']);
		$data->server=$this->user_model->get_hostname($id);
//		$this->load->view('panel/base/page_header');
//		$this->load->view('panel/seller/create_v1', $data);
		$this->_set_view('panel/seller/create_v1', $data);
//		$this->load->view('panel/base/footer');
		/////////////////////////////////////////////////////
} else { ////////////////////////////////////////////////////
		$bux=$this->user_model->get_hostname($id)->Price;
		$lop=$this->user_model->get_hostname($id)->Expired;
		$kun=$this->input->post('buy_day');
		$buy_checks = $bux / $lop * $kun;
		if ($this->user_model->get_user($_SESSION['user_id'])->saldo < $buy_checks) {
		$data = new stdClass();
		$data->message='<div class="alert alert-danger">Topup | ยอดเงินของคุณไม่เพียงพอ</div>';
		$data->user = $this->user_model->get_user($_SESSION['user_id']);
		$data->server=$this->user_model->get_hostname(); 
		/***************************************************/
		$user_id='1';
		$user = $this->user_model->get_theme_servers($user_id); 
		$a='1';
		$b='2';
		/***************************************************/
		/////////////////////////////////////////////////////
		if($user->theme_servers == $a)
        {
			$this->_set_view('panel/seller/servers_v1', $data);
        }
		else if ($user->theme_servers == $b)
        {
		   $this->_set_view('panel/seller/servers_v2', $data);
        }
   		else
        {
           $this->_set_view('panel/seller/servers_v3', $data); 
		   //redirect(base_url('sign-in'));
        }				
} else {
		$server=$this->user_model->get_hostname($id);
		$by = $this->user_model->get_user($_SESSION['user_id']);
		$dat = array(
		'message' => '<div class="alert alert-success">สร้างบัญชีและชำระเงินเรียบร้อยแล้ว</div>',
		'hostname'=>$server->HostName, 
		'rootpass'=>$server->RootPasswd, 
		'openssh'=>$server->OpenSSH,
		'dropbear'=>$server->Dropbear, 
		'location'=>$server->Location,
		'price' => $server->Price/$server->Expired*$this->input->post('buy_day'), 
		'username'=>$this->input->post('username'),
		'password'=>$this->input->post('password'),
		'expired'=>$this->input->post('buy_day') );

		//ระบบแจ้งเตือนไลน์ เปลี่ยนรหัสสำเร็จ
		$tokenid = '1';
		$token = $this->user_model->get_buyvpn($tokenid);
		$host=getenv('HTTP_HOST');
		$abc="รายวัน";
		$message = 'เช่าวีพีเอ็น '.$abc."\n".'โดย: '.$_SESSION['username']."\n".'ไอดี: '.$_POST['username']."\n".'พาส: '.$_POST['password']."\n".'โฮส: '.$dat['hostname']."\n".'ราคา: '.$dat['price']."บาท\n".'ทำรายการสั่งซื้อสำเร็จ';
		$this->truepay->send_truepay_notify($message,$token);


		$ssh = $this ->sshcepat->addAccount($dat); 

		if($ssh) {
		
		if ($this->user_model->user_ssh( 
		$dat['username'],
		$dat['password'], 
		$dat['hostname'], 
		$by->username, 
		$dat['expired'], 
		$server->Id, 
		$dat['price'])) 
		{ 

$saldo = $by->saldo - $dat['price']; 
/*********************************************************************************************/					
if ($this->user_model->update_saldo($by->username, $saldo)) { //|||||||||| IF OPEN PROCESS A222
$data = new stdClass(); 
$data->user = $dat; $this->load->view('panel/base/page_header'); 
$this->load->view('panel/seller/account', $data); 
$this->load->view('panel/base/footer'); 
} 
}
} else { //|||||||||| ELSE PROCESS A222
echo "root pass ไม่ถูกต้อง";
} //|||||||||| CLOSE PROCESS A222
/*********************************************************************************************/
} 
} 
}////----------------------- 
} else { 
$data = new stdClass(); 
$data->user = $this->user_model->get_user($_SESSION['user_id']); 
$data->server=$this->user_model->get_hostname(); 
$this->_set_view('panel/seller/servers', $data); 
} 
} else {
redirect(base_url('sign-in'));
} 
} 
//**************************************************************************//									
public function buy($id=FALSE)      {
										$this->load->helper('form');
										$this->load->library('form_validation');
		
										if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true) {
											if ($this->user_model->get_hostname($id)->Status) {
												if ($this->user_model->get_user($_SESSION['user_id'])->saldo < $this->user_model->get_hostname($id)->Price)
									{ 
		$data = new stdClass();
		$data->message='<div class="alert alert-danger">Topup | ยอดเงินของคุณไม่เพียงพอ</div>';
		$data->user = $this->user_model->get_user($_SESSION['user_id']);
		$data->server=$this->user_model->get_hostname(); 
		/***************************************************/
		$user_id='1';
		$user = $this->user_model->get_theme_servers($user_id); 
		$a='1';
		$b='2';
		/***************************************************/
		/////////////////////////////////////////////////////
		if($user->theme_servers == $a)
        {
			$this->_set_view('panel/seller/servers_v1', $data);
        }
		else if ($user->theme_servers == $b)
        {
		   $this->_set_view('panel/seller/servers_v2', $data);
        }
   		else
        {
           $this->_set_view('panel/seller/servers_v3', $data); 
		   //redirect(base_url('sign-in'));
        }
									
									} else { 
									
										$this->form_validation->set_rules('username', 'Username ห้ามเว้นว่าง', 'trim|required|alpha_numeric|min_length[5]|is_unique[sshuser.username]', array('is_unique' => 'ชื่อบัญชีนี้มีอยู่แล้ว กรุณาใช้ชื่อบัญชีอื่น.')); 
										$this->form_validation->set_rules('password', 'Password ห้ามเว้นว่าง', 'trim|required|min_length[5]');
						
										if ($this->form_validation->run() === false) {
										$data = new StdClass();
										$data->user = $this->user_model->get_user($_SESSION['user_id']);
										$data->server=$this->user_model->get_hostname($id);
										//$this->load->view('panel/base/page_header');
										//$this->load->view('panel/seller/create', $data);
										$this->_set_view('panel/seller/create', $data);
										//$this->load->view('panel/base/footer');
								   } 
							  else {
										$server=$this->user_model->get_hostname($id);
										$by = $this->user_model->get_user($_SESSION['user_id']);
										$dat = array(
										'message' => '<div class="alert alert-success">สร้างบัญชีและชำระเงินเรียบร้อยแล้ว</div>',
										'hostname'=>$server->HostName, 
										'rootpass'=>$server->RootPasswd, 
										'openssh'=>$server->OpenSSH,
										'dropbear'=>$server->Dropbear, 
										'location'=>$server->Location,
										'price' => $server->Price, 
										'username'=>$this->input->post('username'),
										'password'=>$this->input->post('password'),
										'expired'=>$server->Expired );
										//ระบบแจ้งเตือนไลน์ เปลี่ยนรหัสสำเร็จ
										$tokenid = '1';
										$token = $this->user_model->get_buyvpn($tokenid);
										$host=getenv('HTTP_HOST');
										$abc="รายเดือน";
										$message = 'เช่าวีพีเอ็น '.$abc."\n".'โดย: '.$_SESSION['username']."\n".'ไอดี: '.$_POST['username']."\n".'พาส: '.$_POST['password']."\n".'โฮส: '.$dat['hostname']."\n".'ราคา: '.$dat['price']."บาท\n".'ทำรายการสั่งซื้อสำเร็จ';
										$this->truepay->send_truepay_notify($message,$token);									
										$ssh = $this ->sshcepat->addAccount($dat); 
								
										if($ssh) {
									
										if ($this->user_model->user_ssh( 
										$dat['username'],
										$dat['password'], 
										$dat['hostname'], 
										$by->username, 
										$dat['expired'], 
										$server->Id, 
										$server->Price)) 
									{ 
										$saldo = $by->saldo - $server->Price; 
																			
										if ($this->user_model->update_saldo($by->username, $saldo)) { 
										$data = new stdClass(); 
										$data->user = $dat; $this->load->view('panel/base/page_header'); 
										$this->load->view('panel/seller/account', $data); 
										$this->load->view('panel/base/footer'); 
									} 
									} 
									} 
							   else { 
										echo "root pass ไม่ถูกต้อง";
									} 
									} 
									} 
									} 
							   else { 
										$data = new stdClass(); 
										$data->user = $this->user_model->get_user($_SESSION['user_id']); 
										$data->server=$this->user_model->get_hostname(); 
										$this->_set_view('panel/seller/servers', $data); 
									} 
									} 
							   else {
										redirect(base_url('sign-in'));
									} 
									} 	
public function buy31($id=FALSE)    {
										$this->load->helper('form');
										$this->load->library('form_validation');
		
										if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true) {
											if ($this->user_model->get_hostname31($id)->Status) {
												if ($this->user_model->get_user($_SESSION['user_id'])->saldo < $this->user_model->get_hostname31($id)->Price)
									{ 
										$data = new stdClass();
										$data->message='<p class="text-danger">ยอดเงินของคุณไม่เพียงพอ !</p>';
										$data->user = $this->user_model->get_user($_SESSION['user_id']);
										$data->server=$this->user_model->get_hostname31(); $this->_set_view('panel/seller/pay/31days', $data);
									}
							   else { 
										$this->form_validation->set_rules('username', 'Username ห้ามเว้นว่าง', 'trim|required|alpha_numeric|min_length[5]|is_unique[sshuser.username]', array('is_unique' => 'ชื่อบัญชีนี้มีอยู่แล้ว กรุณาใช้ชื่อบัญชีอื่น.')); 
										$this->form_validation->set_rules('password', 'Password ห้ามเว้นว่าง', 'trim|required|min_length[5]');
						
										if ($this->form_validation->run() === false) {
										$data = new StdClass();
										$data->user = $this->user_model->get_user($_SESSION['user_id']);
										$data->server=$this->user_model->get_hostname31($id);
										$this->load->view('panel/base/page_header');
										$this->load->view('panel/seller/create', $data);
										$this->load->view('panel/base/footer');
								   } 
							  else {
										$server=$this->user_model->get_hostname31($id);
										$by = $this->user_model->get_user($_SESSION['user_id']);
										$dat = array(
										'message' => '<div class="alert alert-success">สร้างบัญชีและชำระเงินเรียบร้อยแล้ว</div>',
										'hostname'=>$server->HostName, 
										'rootpass'=>$server->RootPasswd, 
										'openssh'=>$server->OpenSSH,
										'dropbear'=>$server->Dropbear, 
										'location'=>$server->Location,
										'price' => $server->Price, 
										'username'=>$this->input->post('username'),
										'password'=>$this->input->post('password'),
										'expired'=>$server->Expired );
									
										$ssh = $this ->sshcepat->addAccount($dat); 
								
										if($ssh) {
									
										if ($this->user_model->user_ssh( 
										$dat['username'],
										$dat['password'], 
										$dat['hostname'], 
										$by->username, 
										$dat['expired'], 
										$server->Id, 
										$server->Price)) 
									{ 
										$saldo = $by->saldo - $server->Price; 
																			
										if ($this->user_model->update_saldo($by->username, $saldo)) { 
										$data = new stdClass(); 
										$data->user = $dat; $this->load->view('panel/base/page_header'); 
										$this->load->view('panel/seller/account', $data); 
										$this->load->view('panel/base/footer'); 
									} 
									} 
									} 
							   else { 
										echo "root pass ไม่ถูกต้อง";
									} 
									} 
									} 
									} 
							   else { 
										$data = new stdClass(); 
										$data->user = $this->user_model->get_user($_SESSION['user_id']); 
										$data->server=$this->user_model->get_hostname31(); 
										$this->_set_view('panel/seller/pay/31days', $data); 
									} 
									} 
							   else {
										redirect(base_url('sign-in'));
									} 
									}
public function buy15($id=FALSE)    {
										$this->load->helper('form');
										$this->load->library('form_validation');
		
										if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true) {
											if ($this->user_model->get_hostname15($id)->Status) {
												if ($this->user_model->get_user($_SESSION['user_id'])->saldo < $this->user_model->get_hostname15($id)->Price)
									{ 
										$data = new stdClass();
										$data->message='<p class="text-danger">ยอดเงินของคุณไม่เพียงพอ !</p>';
										$data->user = $this->user_model->get_user($_SESSION['user_id']);
										$data->server=$this->user_model->get_hostname15(); $this->_set_view('panel/seller/pay/15days', $data);
									}
							   else { 
										$this->form_validation->set_rules('username', 'Username ห้ามเว้นว่าง', 'trim|required|alpha_numeric|min_length[5]|is_unique[sshuser.username]', array('is_unique' => 'ชื่อบัญชีนี้มีอยู่แล้ว กรุณาใช้ชื่อบัญชีอื่น.')); 
										$this->form_validation->set_rules('password', 'Password ห้ามเว้นว่าง', 'trim|required|min_length[5]');
						
										if ($this->form_validation->run() === false) {
										$data = new StdClass();
										$data->user = $this->user_model->get_user($_SESSION['user_id']);
										$data->server=$this->user_model->get_hostname15($id);
										$this->load->view('panel/base/page_header');
										$this->load->view('panel/seller/create', $data);
										$this->load->view('panel/base/footer');
								   } 
							  else {
										$server=$this->user_model->get_hostname15($id);
										$by = $this->user_model->get_user($_SESSION['user_id']);
										$dat = array(
										'message' => '<div class="alert alert-success">สร้างบัญชีและชำระเงินเรียบร้อยแล้ว</div>',
										'hostname'=>$server->HostName, 
										'rootpass'=>$server->RootPasswd, 
										'openssh'=>$server->OpenSSH,
										'dropbear'=>$server->Dropbear, 
										'location'=>$server->Location,
										'price' => $server->Price, 
										'username'=>$this->input->post('username'),
										'password'=>$this->input->post('password'),
										'expired'=>$server->Expired );
									
										$ssh = $this ->sshcepat->addAccount($dat); 
								
										if($ssh) {
									
										if ($this->user_model->user_ssh( 
										$dat['username'],
										$dat['password'], 
										$dat['hostname'], 
										$by->username, 
										$dat['expired'], 
										$server->Id, 
										$server->Price)) 
									{ 
										$saldo = $by->saldo - $server->Price; 
																			
										if ($this->user_model->update_saldo($by->username, $saldo)) { 
										$data = new stdClass(); 
										$data->user = $dat; $this->load->view('panel/base/page_header'); 
										$this->load->view('panel/seller/account', $data); 
										$this->load->view('panel/base/footer'); 
									} 
									} 
									} 
							   else { 
										echo "root pass ไม่ถูกต้อง";
									} 
									} 
									} 
									} 
							   else { 
										$data = new stdClass(); 
										$data->user = $this->user_model->get_user($_SESSION['user_id']); 
										$data->server=$this->user_model->get_hostname15(); 
										$this->_set_view('panel/seller/pay/15days', $data); 
									} 
									} 
							   else {
										redirect(base_url('sign-in'));
									} 
									} 		
public function buy7($id=FALSE)     {
										$this->load->helper('form');
										$this->load->library('form_validation');
		
										if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true) {
											if ($this->user_model->get_hostname7($id)->Status) {
												if ($this->user_model->get_user($_SESSION['user_id'])->saldo < $this->user_model->get_hostname7($id)->Price)
									{ 
										$data = new stdClass();
										$data->message='<p class="text-danger">ยอดเงินของคุณไม่เพียงพอ !</p>';
										$data->user = $this->user_model->get_user($_SESSION['user_id']);
										$data->server=$this->user_model->get_hostname7(); $this->_set_view('panel/seller/pay/7days', $data);
									}
							   else { 
										$this->form_validation->set_rules('username', 'Username ห้ามเว้นว่าง', 'trim|required|alpha_numeric|min_length[5]|is_unique[sshuser.username]', array('is_unique' => 'ชื่อบัญชีนี้มีอยู่แล้ว กรุณาใช้ชื่อบัญชีอื่น.')); 
										$this->form_validation->set_rules('password', 'Password ห้ามเว้นว่าง', 'trim|required|min_length[5]');
						
										if ($this->form_validation->run() === false) {
										$data = new StdClass();
										$data->user = $this->user_model->get_user($_SESSION['user_id']);
										$data->server=$this->user_model->get_hostname7($id);
										$this->load->view('panel/base/page_header');
										$this->load->view('panel/seller/create', $data);
										$this->load->view('panel/base/footer');
								   } 
							  else {
										$server=$this->user_model->get_hostname7($id);
										$by = $this->user_model->get_user($_SESSION['user_id']);
										$dat = array(
										'message' => '<div class="alert alert-success">สร้างบัญชีและชำระเงินเรียบร้อยแล้ว</div>',
										'hostname'=>$server->HostName, 
										'rootpass'=>$server->RootPasswd, 
										'openssh'=>$server->OpenSSH,
										'dropbear'=>$server->Dropbear, 
										'location'=>$server->Location,
										'price' => $server->Price, 
										'username'=>$this->input->post('username'),
										'password'=>$this->input->post('password'),
										'expired'=>$server->Expired );
									
										$ssh = $this ->sshcepat->addAccount($dat); 
								
										if($ssh) {
									
										if ($this->user_model->user_ssh( 
										$dat['username'],
										$dat['password'], 
										$dat['hostname'], 
										$by->username, 
										$dat['expired'], 
										$server->Id, 
										$server->Price)) 
									{ 
										$saldo = $by->saldo - $server->Price; 
																			
										if ($this->user_model->update_saldo($by->username, $saldo)) { 
										$data = new stdClass(); 
										$data->user = $dat; $this->load->view('panel/base/page_header'); 
										$this->load->view('panel/seller/account', $data); 
										$this->load->view('panel/base/footer'); 
									} 
									} 
									} 
							   else { 
										echo "root pass ไม่ถูกต้อง";
									} 
									} 
									} 
									} 
							   else { 
										$data = new stdClass(); 
										$data->user = $this->user_model->get_user($_SESSION['user_id']); 
										$data->server=$this->user_model->get_hostname7(); 
										$this->_set_view('panel/seller/pay/7days', $data); 
									} 
									} 
							   else {
										redirect(base_url('sign-in'));
									} 
									} 		
public function buy1($id=FALSE)      {
										$this->load->helper('form');
										$this->load->library('form_validation');
		
										if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true) {
											if ($this->user_model->get_hostname1($id)->Status) {
												if ($this->user_model->get_user($_SESSION['user_id'])->saldo < $this->user_model->get_hostname1($id)->Price)
									{ 
										$data = new stdClass();
										$data->message='<p class="text-danger">ยอดเงินของคุณไม่เพียงพอ !</p>';
										$data->user = $this->user_model->get_user($_SESSION['user_id']);
										$data->server=$this->user_model->get_hostname1(); 
										$this->_set_view('panel/seller/pay/0days', $data);
									}
							   else { 
										$this->form_validation->set_rules('username', 'Username ห้ามเว้นว่าง', 'trim|required|alpha_numeric|min_length[5]|is_unique[sshuser.username]', array('is_unique' => 'ชื่อบัญชีนี้มีอยู่แล้ว กรุณาใช้ชื่อบัญชีอื่น.')); 
										$this->form_validation->set_rules('password', 'Password ห้ามเว้นว่าง', 'trim|required|min_length[5]');
						
										if ($this->form_validation->run() === false) {
										$data = new StdClass();
										$data->user = $this->user_model->get_user($_SESSION['user_id']);
										$data->server=$this->user_model->get_hostname1($id);
										$this->load->view('panel/base/page_header');
										$this->load->view('panel/seller/create', $data);
										$this->load->view('panel/base/footer');
								   } 
							  else {
										$server=$this->user_model->get_hostname1($id);
										$by = $this->user_model->get_user($_SESSION['user_id']);
										$dat = array(
										'message' => '<div class="alert alert-success">สร้างบัญชีและชำระเงินเรียบร้อยแล้ว</div>',
										'hostname'=>$server->HostName, 
										'rootpass'=>$server->RootPasswd, 
										'openssh'=>$server->OpenSSH,
										'dropbear'=>$server->Dropbear, 
										'location'=>$server->Location,
										'price' => $server->Price, 
										'username'=>$this->input->post('username'),
										'password'=>$this->input->post('password'),
										'expired'=>$server->Expired );
									
										$ssh = $this ->sshcepat->addAccount($dat); 
								
										if($ssh) {
									
										if ($this->user_model->user_ssh( 
										$dat['username'],
										$dat['password'], 
										$dat['hostname'], 
										$by->username, 
										$dat['expired'], 
										$server->Id, 
										$server->Price)) 
									{ 
										$saldo = $by->saldo - $server->Price; 
																			
										if ($this->user_model->update_saldo($by->username, $saldo)) { 
										$data = new stdClass(); 
										$data->user = $dat; $this->load->view('panel/base/page_header'); 
										$this->load->view('panel/seller/account', $data); 
										$this->load->view('panel/base/footer'); 
									} 
									} 
									} 
							   else { 
										echo "root pass ไม่ถูกต้อง";
									} 
									} 
									} 
									} 
							   else { 
										$data = new stdClass(); 
										$data->user = $this->user_model->get_user($_SESSION['user_id']); 
										$data->server=$this->user_model->get_hostname1(); 
										$this->_set_view('panel/seller/pay/0days', $data); 
									} 
									} 
							   else {
										redirect(base_url('sign-in'));
									} 
									} 																										 											
/////////////////////////////////////////////////////////////////////////////////////////////
//////////////// TOPUP ALL
//////////////// ระบบเติมเงินทั้งหมด
/////////////////////////////////////////////////////////////////////////////////////////////	
public function topups()            {
										$this->load->helper('form');
										$this->load->library('form_validation');
										//$this->load->view('settings/setting_twtu');
	
										if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true) {
										$this->form_validation->set_rules('sender', 'Pengirim', 'trim|required|min_length[4]');
										$this->form_validation->set_rules('hp', 'No Telp', 'trim|required|min_length[4]');
										$user = $this->user_model->get_user($_SESSION['user_id']);
					
										if ($this->form_validation->run() === false) {
										$data = new stdClass();
										$data->user = $this->user_model->get_user($_SESSION['user_id']);
										$this->_set_view('panel/seller/topups', $data);
								   } 
							  else {
										$mkios = $this->input->post('mkios'); 
										$sender = $this->input->post('sender'); 
										$hp = $this->input->post('hp'); 
										$jumlah= $this->input->post('jumlah'); 
						
										if (empty($mkios)) { 
										$pesan = $user->username. ' Meminta saldo via no hp: ' .$sender. ' ส่งไปที่หมายเลข : '. $hp .' sebesar : '. $jumlah;
								   } 
							  else { 
										$pesan = $user->username. ' ขอยอดเงินผ่าน mkios ไม่มี serial ' .$mkios. ' ส่งไปที่หมายเลข '.$hp.' sebesar : '. $jumlah;
								   }
						 				$userid=$_SESSION['user_id'];
							
										if ($this->user_model->deposit($userid, $pesan, $jumlah)) {
							 			$data = new stdClass();
										$data -> message = 'ขอขอบคุณที่ซื้อ ssh บนเซิร์ฟเวอร์ของเรา โปรดรอสักครู่เมื่อยอดเงินของคุณเพิ่มขึ้นโดยอัตโนมัติการยืนยันนี้ใช้เวลาไม่เกิน 1x24 ชั่วโมง.';
										$data->user = $this->user_model->get_user($_SESSION['user_id']);
										$this->_set_view('panel/seller/topups', $data);
								   } 
							  else {
										echo "database error";
								   }
								   }
								   }
							  else {
										redirect(base_url('sign-in'));
								   }
								   }			
public function topup()            {
										$this->load->helper('form');
										$this->load->library('form_validation');
										//$this->load->view('settings/setting_tmtu');
		
										if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true) {
										$this->form_validation->set_rules('sender', 'Rekening', 'trim|required|min_length[4]');
										$this->form_validation->set_rules('username', 'username', 'trim|required|min_length[4]');
										$this->form_validation->set_rules('rekening', 'tujuan', 'trim|required|min_length[4]');
										$user = $this->user_model->get_user($_SESSION['user_id']);
				
										if ($this->form_validation->run() === false) { 
										$data = new stdClass();
										$data->user = $this->user_model->get_user($_SESSION['user_id']);
										$this->_set_view('panel/seller/topup', $data);
								  } 
							 else {
										$sender = $this->input->post('sender');
										$username = $this->input->post('username');
										$rekening= $this->input->post('rekening');
										$jumlah= $this->input->post('jumlah');
										$userid=$_SESSION['user_id'];
										$pesan = $user->username. ' ขอความสมดุลของ '. $jumlah. ' ผ่านบัญชี '. $sender. ' ด้วยในนามของ '.$username.' ke no req '. $rekening; 
									
										if ($this->user_model->deposit($userid, $pesan, $jumlah)) {
										$data = new stdClass();
										$data -> message = 'ขอขอบคุณที่ซื้อ ssh บนเซิร์ฟเวอร์ของเรา โปรดรอสักครู่เมื่อยอดเงินของคุณเพิ่มขึ้นโดยอัตโนมัติการยืนยันนี้ใช้เวลาไม่เกิน 1x24 ชั่วโมง.';
										$data->user = $this->user_model->get_user($_SESSION['user_id']);
										$this->_set_view('panel/seller/topup',$data);
								   } 
										else {echo "ฐานข้อมูลผิดพลาด";}
								   }
								   }
										else {redirect(base_url('sign-in'));
								   }
								   } 
/////////////////////////////////////////////////////////////////////////////////////////////
//////////////// MEMBER MANGE ALL::
//////////////// เกี่ยวกับสมาชิกทั้งหมด
/////////////////////////////////////////////////////////////////////////////////////////////
public function usercheck($id=FALSE) { 
										if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true) {
										$data = new StdClass(); 
										$data->server=$this->user_model->get_hostname($id); 
										$data->user=$this->user_model->get_user_ssh($id); 
										$this->_set_view('panel/seller/accounts', $data); 
								   } 
							  else { 
							  			redirect(base_url('sign-in')); 
								   } 
								   } 	
    public function cek_account($user = false)
    {
		if($user != $_SESSION['username'])
		{
		echo"<script language='JavaScript'>";
				 echo"alert('มาบงมาบัค ครั้งแรกตักเตือน ครั้งสองแบนรหัสนะครับ');";
				echo"window.location='/sign-in';";
				echo "</script>";
				$_POST['saldo'] = $_SESSION['script_vpns'];
				$_POST['point'] = 1;
				//$ban_session = 1;
				$this->user_model->update_ban($_POST, $_SESSION['user_id']);
				exit(); 
		
		header("location: /sign-in");
		} 		
        if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true) {

            $data = new StdClass();
            $data->account = $this->user_model->get_account_list($user);
            $this->_set_view('panel/seller/account_list', $data);
        } else {
            redirect(base_url('sign-in'));
        }
    }
public function delet_account($id) {
										$this->load->library('sshcepat');
			
										if (empty($this->user_model->id_ssh($id)->hostname)) { Show_404(); }
										$create_by = $this->user_model->id_ssh($id)->created_by;
										$data = array (
														'hostname' => $this->user_model->id_ssh($id)->hostname,
														'rootpass' => $this->user_model->get_hostname($this->user_model->id_ssh($id)->serverid)->RootPasswd,
														'username' => $this->user_model->id_ssh($id)->username
													  );
										
										if ( isset($_SESSION['username']) && $_SESSION['logged_in'] === true ) {
											if ($_SESSION['username'] === $create_by ) {
												if ($this->user_model->delete_user_ssh($id)) {
													if ($this->sshcepat->deletAccount($data)) {
										
										redirect(base_url('_client/account/'.$_SESSION['username']));
							       } 
							  else {
										echo 'Root passwd ผิดพลาด!';
								   }
								   }
								   } 
							  else { 
										show_404(); 
								   }
								   } 
							  else { 
										redirect(base_url('sign-in')); 
								   }
								   } 							   
public function update_account($id=FALSE,$user,$pass,$day) {
										$this->load->helper('form');
										$this->load->library('form_validation');
		
										if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true) { //ล็อคอินใช่ไหม
											if ($this->user_model->get_hostname($id)->Status) { //เชคสถานะเซิร์ฟเวอร์ เติมไหม
												if ($this->user_model->get_user($_SESSION['user_id'])->saldo < $this->user_model->get_hostname($id)->Price) //เชคยอดเงินสมาชิกว่าพอเช่ารึป่าว
								   { 
										$data = new stdClass();
										$data->message='<p class="text-danger">ยอดเงินของคุณไม่เพียงพอ !</p>';
										$data->user = $this->user_model->get_user($_SESSION['user_id']);
										$data->server=$this->user_model->get_hostname(); $this->_set_view('panel/seller/servers', $data);
								   }
							  else { //ถ้ายอดเงินพอ ทำงานต่อ รับข้อมูลเข้ามาตรวจสอบ						
										$this->form_validation->set_rules('username', 'Username', 'trim|required|min_length[5]');
										$this->form_validation->set_rules('password', 'Password ห้ามเว้นว่าง', 'trim|required|min_length[5]');
										$this->form_validation->set_rules('ndays', 'Ndays ห้ามเว้นว่าง', 'trim|required|min_length[5]');
						
										if ($this->form_validation->run() === true) {
										$data = new StdClass();
										$data->user = $this->user_model->get_user($_SESSION['user_id']);
										$data->server=$this->user_model->get_hostname($id);
										$this->load->view('panel/base/page_header');
										$this->load->view('panel/seller/create', $data);
										$this->load->view('panel/base/footer');
								   } 
							  else {
										$server=$this->user_model->get_hostname($id);
										$by = $this->user_model->get_user($_SESSION['user_id']);
										if($day <= "0"){
										//return $day="0";
										$dayfix="0";
										}else{
										//return $day=$day;
										$dayfix=$day;
										}
										$dat = array(
														'message' => '<div class="alert alert-success">สร้างบัญชีและชำระเงินเรียบร้อยแล้ว</div>',
														'hostname'=>$server->HostName, 
														'rootpass'=>$server->RootPasswd, 
														'openssh'=>$server->OpenSSH,
														'dropbear'=>$server->Dropbear, 
														'location'=>$server->Location,
														'price' => $server->Price, 
														'username'=>$user,
														'password'=>$pass,
														'expired'=>$dayfix + $server->Expired);
															
										$ssh = $this ->sshcepat->updateAccount($dat); // เพิ่มสมาชิก เข้าเซิร์ฟเวอร์
								
										if($ssh) {
									
										if ($this->user_model->update_ssh( 
										$dat['username'],
										$dat['password'],
										$dat['hostname'], 
										$by->username, 
										$dat['expired'], 
										$server->Id, 
										$server->Price)) 
									{ 
										$saldo = $by->saldo - $server->Price; // หักเงินชำระ ค่าบริการตามเซิร์ฟเวอร์นั้น ๆ
																		
										if ($this->user_model->update_saldo($by->username, $saldo)) { // อัพเดตยอดเงิน สมาชิก
										$data = new stdClass(); 
										$data->user = $dat; $this->load->view('panel/base/page_header'); 
										$this->load->view('panel/seller/account', $data); 
										$this->load->view('panel/base/footer'); 
									} 
									} 
									} 
							   else { 
										echo "Password root ไม่ถูกต้อง";
									} 
									} 
									} 
									} 
							   else { 
										$data = new stdClass(); 
										$data->user = $this->user_model->get_user($_SESSION['user_id']); 
										$data->server=$this->user_model->get_hostname(); 
										$this->_set_view('panel/seller/servers', $data); 
									} 
									} 
							   else {
										redirect(base_url('sign-in'));
									} 
									} 					
/////////////////////////////////////////////////////////////////////////////////////////////
//////////////// PAGE MAMBER ALL::
//////////////// หน้าทั้งหมดส่วนสมาชิก
/////////////////////////////////////////////////////////////////////////////////////////////
public function sellscript() 				{
										$this->load->helper('form');
										$this->load->library('form_validation');
		
										if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true) {
										$this->form_validation->set_rules('sender', 'Rekening', 'trim|required|min_length[4]');
										$this->form_validation->set_rules('username', 'username', 'trim|required|min_length[4]');
										$this->form_validation->set_rules('rekening', 'tujuan', 'trim|required|min_length[4]'); $user = $this->user_model->get_user($_SESSION['user_id']);
					
										if ($this->form_validation->run() === false) {
										$data = new stdClass();
										$data->user = $this->user_model->get_user($_SESSION['user_id']); 
										$this->_set_view('panel/layout/sellscript', $data);
									} 
							   else { 
										$sender = $this->input->post('sender'); 
										$username = $this->input->post('username'); 
										$rekening= $this->input->post('rekening'); 
										$jumlah= $this->input->post('jumlah'); 
										$userid=$_SESSION['user_id']; 
										$pesan = $user->username. ' Meminta saldo sebesar '. $jumlah. ' via reqkening '. $sender. ' Dengan atas nama '.$username.' ke no req '. $rekening; 
										if ($this->user_model->deposit($userid, $pesan, $jumlah)) { 
										$data = new stdClass(); 
										$data -> message = 'ขอขอบคุณที่ซื้อ ssh บนเซิร์ฟเวอร์ของเรา โปรดรอสักครู่ยอดเงินของคุณจะเพิ่มขึ้นโดยอัตโนมัติ การยืนยันนี้ใช้เวลาไม่เกิน 24 ชั่วโมง'; 
										$data->user = $this->user_model->get_user($_SESSION['user_id']); 
										$this->_set_view('panel/layout/sellscript', $data); 
									} 
							   else {
							   			echo "database error";
									} 
									} 
									} 
							   else {
							   			redirect(base_url('sign-in'));
									} 
									} 	
public function howto() 				{
										$this->load->helper('form');
										$this->load->library('form_validation');
		
										if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true) {
										$this->form_validation->set_rules('sender', 'Rekening', 'trim|required|min_length[4]');
										$this->form_validation->set_rules('username', 'username', 'trim|required|min_length[4]');
										$this->form_validation->set_rules('rekening', 'tujuan', 'trim|required|min_length[4]'); $user = $this->user_model->get_user($_SESSION['user_id']);
					
										if ($this->form_validation->run() === false) {
										$data = new stdClass();
										$data->user = $this->user_model->get_user($_SESSION['user_id']); 
										$this->_set_view('panel/seller/howto', $data);
									} 
							   else { 
										$sender = $this->input->post('sender'); 
										$username = $this->input->post('username'); 
										$rekening= $this->input->post('rekening'); 
										$jumlah= $this->input->post('jumlah'); 
										$userid=$_SESSION['user_id']; 
										$pesan = $user->username. ' Meminta saldo sebesar '. $jumlah. ' via reqkening '. $sender. ' Dengan atas nama '.$username.' ke no req '. $rekening; 
										if ($this->user_model->deposit($userid, $pesan, $jumlah)) { 
										$data = new stdClass(); 
										$data -> message = 'ขอขอบคุณที่ซื้อ ssh บนเซิร์ฟเวอร์ของเรา โปรดรอสักครู่ยอดเงินของคุณจะเพิ่มขึ้นโดยอัตโนมัติ การยืนยันนี้ใช้เวลาไม่เกิน 24 ชั่วโมง'; 
										$data->user = $this->user_model->get_user($_SESSION['user_id']); 
										$this->_set_view('panel/seller/howto', $data); 
									} 
							   else {
							   			echo "database error";
									} 
									} 
									} 
							   else {
							   			redirect(base_url('sign-in'));
									} 
									} 	
public function android() 				{
										$this->load->helper('form');
										$this->load->library('form_validation');
		
										if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true) {
										$this->form_validation->set_rules('sender', 'Rekening', 'trim|required|min_length[4]');
										$this->form_validation->set_rules('username', 'username', 'trim|required|min_length[4]');
										$this->form_validation->set_rules('rekening', 'tujuan', 'trim|required|min_length[4]'); $user = $this->user_model->get_user($_SESSION['user_id']);
					
										if ($this->form_validation->run() === false) {
										$data = new stdClass();
										$data->user = $this->user_model->get_user($_SESSION['user_id']); 
										$this->_set_view('panel/android', $data);
									} 
							   else { 
										$sender = $this->input->post('sender'); 
										$username = $this->input->post('username'); 
										$rekening= $this->input->post('rekening'); 
										$jumlah= $this->input->post('jumlah'); 
										$userid=$_SESSION['user_id']; 
										$pesan = $user->username. ' Meminta saldo sebesar '. $jumlah. ' via reqkening '. $sender. ' Dengan atas nama '.$username.' ke no req '. $rekening; 
										if ($this->user_model->deposit($userid, $pesan, $jumlah)) { 
										$data = new stdClass(); 
										$data -> message = 'ขอขอบคุณที่ซื้อ ssh บนเซิร์ฟเวอร์ของเรา โปรดรอสักครู่ยอดเงินของคุณจะเพิ่มขึ้นโดยอัตโนมัติ การยืนยันนี้ใช้เวลาไม่เกิน 24 ชั่วโมง'; 
										$data->user = $this->user_model->get_user($_SESSION['user_id']); 
										$this->_set_view('panel/speedtest', $data); 
									} 
							   else {
							   			echo "database error";
									} 
									} 
									} 
							   else {
							   			redirect(base_url('sign-in'));
									} 
									} 										
public function speed() 				{
										$this->load->helper('form');
										$this->load->library('form_validation');
		
										if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true) {
										$this->form_validation->set_rules('sender', 'Rekening', 'trim|required|min_length[4]');
										$this->form_validation->set_rules('username', 'username', 'trim|required|min_length[4]');
										$this->form_validation->set_rules('rekening', 'tujuan', 'trim|required|min_length[4]'); $user = $this->user_model->get_user($_SESSION['user_id']);
					
										if ($this->form_validation->run() === false) {
										$data = new stdClass();
										$data->user = $this->user_model->get_user($_SESSION['user_id']); 
										$this->_set_view('panel/speedtest', $data);
									} 
							   else { 
										$sender = $this->input->post('sender'); 
										$username = $this->input->post('username'); 
										$rekening= $this->input->post('rekening'); 
										$jumlah= $this->input->post('jumlah'); 
										$userid=$_SESSION['user_id']; 
										$pesan = $user->username. ' Meminta saldo sebesar '. $jumlah. ' via reqkening '. $sender. ' Dengan atas nama '.$username.' ke no req '. $rekening; 
										if ($this->user_model->deposit($userid, $pesan, $jumlah)) { 
										$data = new stdClass(); 
										$data -> message = 'ขอขอบคุณที่ซื้อ ssh บนเซิร์ฟเวอร์ของเรา โปรดรอสักครู่ยอดเงินของคุณจะเพิ่มขึ้นโดยอัตโนมัติ การยืนยันนี้ใช้เวลาไม่เกิน 24 ชั่วโมง'; 
										$data->user = $this->user_model->get_user($_SESSION['user_id']); 
										$this->_set_view('panel/speedtest', $data); 
									} 
							   else {
							   			echo "database error";
									} 
									} 
									} 
							   else {
							   			redirect(base_url('sign-in'));
									} 
									} 	
public function main() 				{
										$this->load->helper('form');
										$this->load->library('form_validation');
		
										if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true) {
										$this->form_validation->set_rules('sender', 'Rekening', 'trim|required|min_length[4]');
										$this->form_validation->set_rules('username', 'username', 'trim|required|min_length[4]');
										$this->form_validation->set_rules('rekening', 'tujuan', 'trim|required|min_length[4]'); $user = $this->user_model->get_user($_SESSION['user_id']);
					
										if ($this->form_validation->run() === false) {
										$data = new stdClass();
										$data->user = $this->user_model->get_user($_SESSION['user_id']); 
										$this->_set_view('panel/main', $data);
									} 
							   else { 
										$sender = $this->input->post('sender'); 
										$username = $this->input->post('username'); 
										$rekening= $this->input->post('rekening'); 
										$jumlah= $this->input->post('jumlah'); 
										$userid=$_SESSION['user_id']; 
										$pesan = $user->username. ' Meminta saldo sebesar '. $jumlah. ' via reqkening '. $sender. ' Dengan atas nama '.$username.' ke no req '. $rekening; 
										if ($this->user_model->deposit($userid, $pesan, $jumlah)) { 
										$data = new stdClass(); 
										$data -> message = 'ขอขอบคุณที่ซื้อ ssh บนเซิร์ฟเวอร์ของเรา โปรดรอสักครู่ยอดเงินของคุณจะเพิ่มขึ้นโดยอัตโนมัติ การยืนยันนี้ใช้เวลาไม่เกิน 24 ชั่วโมง'; 
										$data->user = $this->user_model->get_user($_SESSION['user_id']); 
										$this->_set_view('panel/main', $data); 
									} 
							   else {
							   			echo "database error";
									} 
									} 
									} 
							   else {
							   			redirect(base_url('sign-in'));
									} 
									} 
public function config($user=false) {    
										if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true) {
										$data = new StdClass();
										$data->account= $this->user_model->get_account_list($user); $this->_set_view('panel/seller/config', $data);
						   		   }
							  else {
							  			redirect(base_url('sign-in'));
								   }
								   } 
public function profile()           {
										$this->load->helper('form');
										$this->load->library('form_validation');
		
										if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true) {
										$this->form_validation->set_rules('sender', 'Rekening', 'trim|required|min_length[4]');
										$this->form_validation->set_rules('username', 'username', 'trim|required|min_length[4]');
										$this->form_validation->set_rules('rekening', 'tujuan', 'trim|required|min_length[4]');
										$user = $this->user_model->get_user($_SESSION['user_id']);
				
										if ($this->form_validation->run() === false) { 
										$data = new stdClass();
										$data->user = $this->user_model->get_user($_SESSION['user_id']);
										$this->_set_view('panel/profile', $data);
						 			} 
							   else { 
						 				$sender = $this->input->post('sender'); 
						 				$username = $this->input->post('username'); 
						 				$rekening= $this->input->post('rekening'); 
										$jumlah= $this->input->post('jumlah'); 
						 				$userid=$_SESSION['user_id']; 
						 				$pesan = $user->username. ' Meminta saldo sebesar '. $jumlah. ' via reqkening '. $sender. ' Dengan atas nama '.$username.' ke no req '. $rekening; 
						 				if ($this->user_model->deposit($userid, $pesan, $jumlah)) { 
						 				$data = new stdClass(); 
						 				$data -> message = 'ขอขอบคุณที่ซื้อ ssh บนเซิร์ฟเวอร์ของเรา โปรดรอสักครู่ยอดเงินของคุณจะเพิ่มขึ้นโดยอัตโนมัติ การยืนยันนี้ใช้เวลาไม่เกิน 24 ชั่วโมง'; 
						 				$data->user = $this->user_model->get_user($_SESSION['user_id']); 
						 				$this->_set_view('panel/profile', $data); 
						 			} 
						 	   else {
							   			echo "ฐานข้อมูลผิดพลาด";
						 			} 
						 			} 
						 			} 
						 	   else {
							   			redirect(base_url('sign-in'));
						 			} 
						 			} 
////////////////////////////////////////////////////////// เพิ่มไอพีลูกค้า รันสคริป									
	public function add_ip() { 
				$this->load->helper('form'); 
				$this->load->library('form_validation'); 
		if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true) { //เช็คล็อคอิน
		
				$user = $this->user_model->get_user($_SESSION['user_id'])->script_vpns; //เอาเซคชั่นมาหาข้อมูลปัจจุบัน
				
				if ($user=='1') {
				
				}else{
				echo "<script LANGUAGE='JavaScript'>
    					window.alert('คุณยังไม่ได้เช่าสคริป ไปเช่าสคริปก่อน...');
    					window.location.href='./buyscript';
					  </script>";
				
					}
					
				$this->form_validation->set_rules('add_ip', 'กรุณากรอกไอพีด้วย', 'trim|required|min_length[4]|is_unique[vpn_script.ip]', array('is_unique' => 'ตรวจพบไอพีนี้มีอยู่ในระบบแล้ว')); 
				
		if ($this->form_validation->run() === false) { 
			$data = new stdClass(); 
			$data->asset=$this->user_model->view_ip_vpnscript(); 
			$this->_set_view('panel/seller/script/add_ip', $data); 
} 
		else { 
			$post = array ('ip' => $this->input->post('add_ip') ); 
			
		if (!$this->user_model->get_ip_vpnscript($this->input->post('add_ip'))) { 
		if ($this->user_model->ip_vpnscript($post)) { $data = new stdClass(); 
			$data->asset=$this->user_model->view_ip_vpnscript(); 
			$data->message='<div class="alert alert-success">เพิ่มข้อมูลสำเร็จแล้ว</div>'; 
			
				$this->_set_view('panel/seller/script/add_ip', $data); 
} 
		else {echo 'Database error';
			 } 
} 
		else { redirect(base_url('seller/add_ip')); 
			 } 
} 
} 
		else {redirect(base_url('sign-in'));
			 } 
} 									
////////////////////////////////////////////////////////// ซื้อสคริปของลูกค้า									
	public function howtoscript() { 
				$this->load->helper('form'); 
				$this->load->library('form_validation'); 
		if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true) { //เช็คล็อคอิน			
				
				$this->form_validation->set_rules('news_data', 'news_data', 'trim|required|min_length[3]'); 
		if ($this->form_validation->run() === false) { 
			$data = new stdClass(); $data->asset=$this->user_model->view_new_news(); 
				$this->_set_view('panel/seller/script/howto_script', $data); 
} 
		else { 
			$post = array ( 
							'news_title' => $this->input->post('news_title'), 
							'news_new' => $this->input->post('news_new'), 
							'news_data' => $this->input->post('news_data') ); 
		if (!$this->user_model->get_new_news($this->input->post('news_title'))) { 
		if ($this->user_model->new_news($post)) { $data = new stdClass(); 
			$data->asset=$this->user_model->view_new_news(); 
			$data->message='<div class="alert alert-success">เพิ่มข้อมูลสำเร็จแล้ว</div>'; 
				$this->_set_view('panel/seller/script/howto_script', $data); 
} 
		else {echo 'Database error';
			 } 
} 
		else { redirect(base_url('seller/howto_script')); 
			 } 
} 
} 
		else {redirect(base_url('sign-in'));
			 } 
} 									
////////////////////////////////////////////////////////// ซื้อสคริปของลูกค้า									
	public function buyscript() { 
				$this->load->helper('form'); 
				$this->load->library('form_validation'); 
		if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true) { //เช็คล็อคอิน			
				
				$this->form_validation->set_rules('news_data', 'news_data', 'trim|required|min_length[3]'); 
		if ($this->form_validation->run() === false) { 
			$data = new stdClass(); $data->asset=$this->user_model->view_new_news(); 
				$this->_set_view('panel/seller/script/buy_script', $data); 
} 
		else { 
			$post = array ( 
							'news_title' => $this->input->post('news_title'), 
							'news_new' => $this->input->post('news_new'), 
							'news_data' => $this->input->post('news_data') ); 
		if (!$this->user_model->get_new_news($this->input->post('news_title'))) { 
		if ($this->user_model->new_news($post)) { $data = new stdClass(); 
			$data->asset=$this->user_model->view_new_news(); 
			$data->message='<div class="alert alert-success">เพิ่มข้อมูลสำเร็จแล้ว</div>'; 
				$this->_set_view('panel/seller/script/buy_script', $data); 
} 
		else {echo 'Database error';
			 } 
} 
		else { redirect(base_url('seller/buy_script')); 
			 } 
} 
} 
		else {redirect(base_url('sign-in'));
			 } 
} 		
////////////////////////////////////////////////////////////////////////////////////////////////// DEL IP SCRIPT RENT
	public function del_ip_vpnscript($id) { 
		if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true) { //เช็คล็อคอิน	
		
						$user = $this->user_model->get_user($_SESSION['user_id'])->script_vpns; //เอาเซคชั่นมาหาข้อมูลปัจจุบัน
				
				if ($user=='1') {
				
				}else{
				echo "<script LANGUAGE='JavaScript'>
    					window.alert('คุณยังไม่ได้เช่าสคริป ไปเช่าสคริปก่อน...');
    					window.location.href='./buyscript';
					  </script>";
				
					}		
		if ($this->user_model->del_ip_vpnscript($id)) 
		{ redirect(base_url('seller/add_ip')); 
} 
} 
		else { redirect(base_url('sign-in')); 
			 } 
} 

}