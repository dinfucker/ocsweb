<?php defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->load->library(array('session'));
    }

    public function create_user($username, $email, $password)
    {
        $data = array('username' => $username, 'email' => $email, 'password' => $this->hash_password($password), 'created_at' => date('Y-m-j H:i:s'),);
        return $this->db->insert('users', $data);
    }

    function userListingCount($searchText = '')
    {
        $this->db->select('BaseTbl.id, BaseTbl.username, BaseTbl.saldo, BaseTbl.online_timestamp, Role.role');
        $this->db->from('users as BaseTbl');
        $this->db->join('tbl_roles as Role', 'Role.roleId = BaseTbl.is_admin', 'left');
        if (!empty($searchText)) {
            $likeCriteria = "(BaseTbl.username  LIKE '%" . $searchText . "%'
                            OR  BaseTbl.saldo  LIKE '%" . $searchText . "%'
                            OR  BaseTbl.online_timestamp  LIKE '%" . $searchText . "%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.is_confirmed', 0);
        $query = $this->db->get();
        return $query->num_rows();
    }

    function userListing($searchText = '', $page, $segment)
    {
        $this->db->select('BaseTbl.id, BaseTbl.username, BaseTbl.saldo, BaseTbl.online_timestamp, Role.role');
        $this->db->from('users as BaseTbl');
        $this->db->join('tbl_roles as Role', 'Role.roleId = BaseTbl.is_admin', 'left');
        if (!empty($searchText)) {
            $likeCriteria = "(BaseTbl.username  LIKE '%" . $searchText . "%'
                            OR  BaseTbl.saldo  LIKE '%" . $searchText . "%'
                            OR  BaseTbl.online_timestamp  LIKE '%" . $searchText . "%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.is_confirmed', 0);
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        $result = $query->result();
        return $result;
    }

    function getUserRoles()
    {
        $this->db->select('roleId, role');
        $this->db->from('tbl_roles');
        $query = $this->db->get();
        return $query->result();
    }

    public function online_user($username, $password)
    {
        $data = array('username' => $username, 'password' => $this->hash_password($password), 'online' => "online", 'online_timestamp' => date('Y-m-j H:i:s'),);
        $this->db->where('username', $username);
        return $this->db->update('users', $data);
    }

    public function get_theme_servers($user_id)
    {
        $this->db->from('website');
        $this->db->where('id', $user_id);
        return $this->db->get()->row();
    }
    public function get_topup_action($user_id)
    {
        $this->db->from('wallet');
        $this->db->where('id', $user_id);
        return $this->db->get()->row();
    }	

    public function theme($data)
    {
        return $this->db->update('website', $data);
    }

    public function view_theme()
    {
        return $this->db->get('website')->result_array();
    }

    public function get_all_theme($req)
    {
        $this->db->select('id');
        $this->db->from('website');
        $this->db->where('theme_servers', $req);
        return $this->db->get()->row('id');
    }

    public function get_all_themecreate($req)
    {
        $this->db->select('id');
        $this->db->from('website');
        $this->db->where('theme_create', $req);
        return $this->db->get()->row('id');
    }

    public function offline_user($username)
    {
        $data = array('online' => "offline", 'online_timestamp' => date('Y-m-j H:i:s'),);
        $this->db->where('username', $username);
        return $this->db->update('users', $data);
    }

    public function create_hostname($array)
    {
        return $this->db->insert('server', $array);
    }

    public function resolve_user_login($username, $password)
    {
        $this->db->select('password');
        $this->db->from('users');
        $this->db->where('username', $username);
        $hash = $this->db->get()->row('password');
        return $this->verify_password_hash($password, $hash);
    }

    public function get_user_id_from_username($username)
    {
        $this->db->select('id');
        $this->db->from('users');
        $this->db->where('username', $username);
        return $this->db->get()->row('id');
    }

    public function get_user_id_from_ssh($user, $hostid)
    {
        $this->db->select('id');
        $this->db->from('sshuser');
        $this->db->where('username', $user);
        $this->db->where('serverid', $hostid);
        return $this->db->get()->row('id');
    }

    public function get_user_ssh($hostid)
    {
        $query = $this->db->get_where('sshuser', array('serverid' => $hostid));
        $arr = array();
        foreach ($query->result_array() as $row) {
            $tmp = array('id' => $row['id'], 'username' => $row['username'], 'hostname' => $row['hostname'], 'created_by' => $row['created_by'], 'created_at' => $row['created_at'], 'expired_at' => date("Y-m-j H:i:s", strtotime('+' . $row['expired_at'] . ' days', time())));
            array_push($arr, $tmp);
        }
        return $arr;
    }

    public function seller_notify()
    {
        $arr = array();
        foreach ($this->db->get_where('deposit', array('is_confirmed' => false))->result_array() as $row) {
            $tmp = array('id' => $row['id'], 'userid' => $row['userid'], 'username' => $this->get_user($row['userid'])->username, 'pesan' => $row['pesan'], 'created_at' => $row['created_at']);
            array_push($arr, $tmp);
        }
        return $arr;
    }

    private function _get_seller_msg($id)
    {
        $this->db->from('deposit');
        $this->db->where('id', $id);
        return $this->db->get()->row();
    }

    private function _get_topedit($id)
    {
        $this->db->from('users');
        $this->db->where('id', $id);
        return $this->db->get()->row();
    }

    public function id_ssh($id)
    {
        $this->db->from('sshuser');
        $this->db->where('id', $id);
        return $this->db->get()->row();
    }

    public function update_message($id, $cmd)
    {
        $this->db->where('id', $id);
        if ($cmd == 'konfirm') {
            if ($this->db->update('deposit', array('is_confirmed' => true))) {
                $saldo = $this->_get_seller_msg($id)->jumlah;
                $username = $this->get_user($this->_get_seller_msg($id)->userid)->username;
                $total = $this->get_user($this->_get_seller_msg($id)->userid)->saldo + $saldo;
                return $this->update_saldo($username, $total);
            }
        } elseif ($cmd == 'del') {
            return $this->db->delete('deposit', array('id' => $id));
        } else {
            show_404();
        }
    }

    public function get_user($user_id)
    {
        $this->db->from('users');
        $this->db->where('id', $user_id);
        return $this->db->get()->row();
    }

    private function hash_password($password)
    {
        return password_hash($password, PASSWORD_BCRYPT);
    }

    private function verify_password_hash($password, $hash)
    {
        return password_verify($password, $hash);
    }

    public function get_hostname($id = FALSE)
    {
        if ($id === FALSE) {
            return $this->db->get('server')->result_array();
        }
        $this->db->from('server');
        $this->db->where('Id', $id);
        return $this->db->get()->row();
    }

    public function get_edituser($id = FALSE)
    {
        if ($id === FALSE) {
            return $this->db->get('users')->result_array();
        }
        $this->db->from('users');
        $this->db->where('id', $id);
        return $this->db->get()->row();
    }
	/////////////////////////////////////// XXX
    public function update_ban($post, $id)
    {
		$post['point'] = $post['saldo'] + $post['point'];
        $this->db->where('id', $id);
        return $this->db->update('users', array('script_vpns' => $post['point']));
    }
	/////////////////////////////////////// XXX
    public function update_edituser($post, $id)
    {
        $this->db->where('id', $id);
        return $this->db->update('users', array('saldo' => $post['saldo']));
    }

    public function top_edituser($post, $id)
    {
        $post['point'] = $post['saldo'] + $post['point'];
        $this->db->where('id', $id);
        return $this->db->update('users', array('saldo' => $post['point']));
    }

    public function update_server($post, $id)
    {
        $this->db->where('Id', $id);
        return $this->db->update('server', $post);
    }

    public function delete_server($id)
    {
        $this->db->where('Id', $id);
        return $this->db->delete('server', array('Id' => $id));
    }

    public function update_login($post)
    {
        $data = array('password' => $this->hash_password($post['password']));
        $this->db->where('username', $post['username']);
        return $this->db->update('users', $data);
    }

    public function update_saldo($user, $saldo)
    {
        $this->db->where('username', $user);
        return $this->db->update('users', array('username' => $user, 'saldo' => $saldo));
    }

    public function user_ssh($user, $password, $host, $create, $expired, $id, $price)
    {
        $data = array('username' => $user, 'password' => $password, 'hostname' => $host, 'created_by' => $create, 'created_at' => date('Y-m-j H:i:s'), 'expired_at' => $expired, 'serverid' => $id, 'price' => $price);
        return $this->db->insert('sshuser', $data);
    }

    public function deposit($userid, $pesan, $jumlah)
    {
        $data = array('userid' => $userid, 'pesan' => $pesan, 'jumlah' => $jumlah, 'created_at' => date('Y-m-j H:i:s'));
        return $this->db->insert('deposit', $data);
    }

    public function delete_user_ssh($id)
    {
        $this->db->where('id', $id);
        return $this->db->delete('sshuser', array('id' => $id));
    }

    public function asset($data)
    {
        return $this->db->insert('asset', $data);
    }

    public function all_programs($data)
    {
        return $this->db->insert('all_program', $data);
    }

    public function all_filesvpn($data)
    {
        return $this->db->insert('all_filesvpn', $data);
    }

    public function new_news($data)
    {
        return $this->db->insert('new_news', $data);
    }

    public function pro_true($data)
    {
        return $this->db->insert('pro_true', $data);
    }

    public function pro_dtac($data)
    {
        return $this->db->insert('pro_dtac', $data);
    }

    public function pro_ais($data)
    {
        return $this->db->insert('pro_ais', $data);
    }

    public function terms_use($data)
    {
        return $this->db->insert('terms_use', $data);
    }

    public function view_asset()
    {
        return $this->db->get('asset')->result_array();
    }

    public function view_wallet()
    {
        return $this->db->get('wallet')->result_array();
    }

    public function view_token()
    {
        return $this->db->get('token')->result_array();
    }

    public function get_token($req)
    {
        $this->db->select('id');
        $this->db->from('token');
        $this->db->where('login', $req);
        return $this->db->get()->row('id');
    }

    public function get_tokenwallet($tokenid)
    {
        $this->db->select('login');
        $this->db->from('token');
        $this->db->where('id', $tokenid);
        return $this->db->get()->row('login');
    }

    public function get_buyvpn($tokenid)
    {
        $this->db->select('add_vpn');
        $this->db->from('token');
        $this->db->where('id', $tokenid);
        return $this->db->get()->row('add_vpn');
    }

    public function token($data)
    {
        return $this->db->update('token', $data);
    }

    public function post_twtopup($data)
    {
        return $this->db->update('wallet', $data);
    }

    public function post_tmtopup($data)
    {
        return $this->db->update('wallet', $data);
    }

    public function post_x2topup($data)
    {
        return $this->db->update('wallet', $data);
    }

    public function view_all_programs()
    {
        return $this->db->get('all_program')->result_array();
    }

    public function view_users()
    {
        return $this->db->get('users')->result_array();
    }

    public function view_all_filesvpn()
    {
        return $this->db->get('all_filesvpn')->result_array();
    }

    public function view_all_filesdtac()
    {
        return $this->db->get('all_filesvpn')->result_array();
    }

    public function view_all_filestrue()
    {
        return $this->db->get('all_filesvpn')->result_array();
    }

    public function view_new_news()
    {
        return $this->db->get('new_news')->result_array();
    }

    public function view_pro_true()
    {
        return $this->db->get('pro_true')->result_array();
    }

    public function view_pro_dtac()
    {
        return $this->db->get('pro_dtac')->result_array();
    }

    public function view_pro_ais()
    {
        return $this->db->get('pro_ais')->result_array();
    }

    public function view_terms_use()
    {
        return $this->db->get('terms_use')->result_array();
    }

    public function get_hp($hp)
    {
        $this->db->select('id');
        $this->db->from('asset');
        $this->db->where('nohp', $hp);
        return $this->db->get()->row('id');
    }

    public function get_req($req)
    {
        $this->db->select('id');
        $this->db->from('asset');
        $this->db->where('rekening', $req);
        return $this->db->get()->row('id');
    }

    public function get_all_programs($req)
    {
        $this->db->select('id');
        $this->db->from('all_program');
        $this->db->where('pritunl', $req);
        return $this->db->get()->row('id');
    }

    public function get_all_filesvpn($req)
    {
        $this->db->select('id');
        $this->db->from('all_filesvpn');
        $this->db->where('file_name', $req);
        return $this->db->get()->row('id');
    }

    public function get_all_filesdtac($req)
    {
        $this->db->select('id');
        $this->db->from('all_filesvpn');
        $this->db->where('file_name', $req);
        return $this->db->get()->row('id');
    }

    public function get_new_news($req)
    {
        $this->db->select('id');
        $this->db->from('new_news');
        $this->db->where('news_title', $req);
        return $this->db->get()->row('id');
    }

    public function get_pro_true($req)
    {
        $this->db->select('id');
        $this->db->from('pro_true');
        $this->db->where('t_descrip', $req);
        return $this->db->get()->row('id');
    }

    public function get_pro_dtac($req)
    {
        $this->db->select('id');
        $this->db->from('pro_dtac');
        $this->db->where('d_descrip', $req);
        return $this->db->get()->row('id');
    }

    public function get_pro_ais($req)
    {
        $this->db->select('id');
        $this->db->from('pro_ais');
        $this->db->where('a_descrip', $req);
        return $this->db->get()->row('id');
    }

    public function get_terms_use($req)
    {
        $this->db->select('id');
        $this->db->from('terms_use');
        $this->db->where('terms_agree', $req);
        return $this->db->get()->row('id');
    }

    public function del_req($id)
    {
        $this->db->where('id', $id);
        return $this->db->delete('asset', array('id' => $id));
    }

    public function del_token($id)
    {
        $this->db->where('id', $id);
        return $this->db->delete('token', array('id' => $id));
    }

    public function del_all_programs($id)
    {
        $this->db->where('id', $id);
        return $this->db->delete('all_program', array('id' => $id));
    }

    public function del_member($id)
    {
        $this->db->where('id', $id);
        return $this->db->delete('users', array('id' => $id));
    }

    public function del_all_filesvpn($id)
    {
        $this->db->where('id', $id);
        return $this->db->delete('all_filesvpn', array('id' => $id));
    }

    public function del_new_news($id)
    {
        $this->db->where('id', $id);
        return $this->db->delete('new_news', array('id' => $id));
    }

    public function del_pro_true($id)
    {
        $this->db->where('id', $id);
        return $this->db->delete('pro_true', array('id' => $id));
    }

    public function del_pro_dtac($id)
    {
        $this->db->where('id', $id);
        return $this->db->delete('pro_dtac', array('id' => $id));
    }

    public function del_pro_ais($id)
    {
        $this->db->where('id', $id);
        return $this->db->delete('pro_ais', array('id' => $id));
    }

    public function del_terms_use($id)
    {
        $this->db->where('id', $id);
        return $this->db->delete('terms_use', array('id' => $id));
    }

    public function update_ssh($user, $password, $host, $create, $expired, $id, $price)
    {
        $data = array('username' => $user, 'password' => $password, 'hostname' => $host, 'created_by' => $create, 'created_at' => date('Y-m-j H:i:s'), 'expired_at' => $expired, 'serverid' => $id, 'price' => $price);
        $this->db->where('username', $user);
        return $this->db->update('sshuser', $data);
    }

    public function get_account_list($user)
    {
        return $this->db->get_where('sshuser', array('created_by' => $user))->result_array();
    }

    public function get_country()
    {
        $query = $this->db->get('country');
        return $query->result_array();
    }
    public function h_promptpay($post)
    {
        return $this->db->insert('histrory', $post);
    }
    public function c_promptpay($id)
    {
        $this->db->select('id');
        $this->db->from('histrory');
        $this->db->where('NumberWallet', $id);
        return $this->db->get()->row('id');
    }	
    public function get_same_time($id)
    {
        $this->db->from('histrory');
        $this->db->where('NumberWallet', $id);
        return $this->db->get()->row();
    }		
}

?>