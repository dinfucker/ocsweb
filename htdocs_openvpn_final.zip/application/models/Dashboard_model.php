<?php
/*
| -------------------------------------------------------------------
| OCSPAMEL.INFO ( เด็กกระโปรกหาแต่โค๊ด  )
| -------------------------------------------------------------------
|
| TRUE WALLET ID : 083-758-6342 .
|
| https://www.facebook.com/GenesisPresent.co.th
|
| -------------------------------------------------------------------
| A SAMPLE BY : LNWSERVICE
| -------------------------------------------------------------------
|
| หาผลรวมทั้งหมดในส่วนของ หน้าแรกแอดมิน:
|
*/
class Dashboard_model extends CI_Model {
        
    function count_user(){
        $q = "select * from users where active";
        $rs = $this->db->query($q);
        return $rs->num_rows();
    }
    
    function count_server(){
        $q = "select * from server where Status";
        $rs = $this->db->query($q);
        return $rs->num_rows();
    }
    function count_wallet(){
        $q = "select * from histrory where money";
        $rs = $this->db->query($q);
        return $rs->num_rows();
    }
     function count_money(){
        $q = "select * from truemoney where amount";
        $rs = $this->db->query($q);
        return $rs->num_rows();
    }
     function count_ssh(){
        $q = "select * from sshuser where price";
        $rs = $this->db->query($q);
        return $rs->num_rows();
    }
 
}   
?>